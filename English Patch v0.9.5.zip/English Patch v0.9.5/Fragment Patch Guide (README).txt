-----------------------------------------
.hack//frägment Definitive Translation
             v0.9.1
	Patch By: Princess Alice
-----------------------------------------
Needed Items
-----------------------------------------
- A clean copy of .hack//frägment (NOT Coldbird, The title screen should be green and the UI should be Blue)
- ImgBurn or another image writer (ImageBurn is Free and easy to use and will be used in this guide)
- The files included with this readme
-----------------------------------------
How to Patch
-----------------------------------------
1. Mount your CLEAN frägment iso into a drive (This is done by double clicking the iso)
2. Copy ALL of the contents to a seperate folder (Mine is called .hack//frägment (English Patch))
3. Copy the Contents of the [Fragment English Files] Folder into the folder you made in the previous step
4. Overwrite EVERYTHING
5. Open ImgBurn or another Image File writer
6. Click [Create image file from files/folders]
7. In the Source panel, click the folder with a magnifying glass and select the folder you made in Step 2
8. Click Yes
9. Repeat Step 7 for the Destination pane but this time, set the folder as something else (Maybe the folder your clean ISO is in)
10. Click the big button under the Destination Pain (It should be a folder with an arrow pointing to a file)
11. Hit Yes Twice then Ok. If it gives you a fourth window, Make Sure you aren't overwriting something important, and click Yes to All
12. Click OK
13. Profit